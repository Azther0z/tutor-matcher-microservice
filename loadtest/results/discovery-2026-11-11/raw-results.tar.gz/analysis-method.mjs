import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifactDir = path.resolve(
  root,
  process.argv[2] || "loadtest/results/discovery-2026-11-11",
);
const expectedServiceCounts = {
  "api-gateway": 1,
  "auth-service": 1,
  "booking-service": 1,
  "review-service": 1,
};
const coreServices = Object.keys(expectedServiceCounts).concat("tutor-service");
const categories = ["broad", "selective", "availability"];
const finite = (value) => (Number.isFinite(value) ? value : null);
const round = (value, digits = 2) =>
  Number.isFinite(value) ? Number(value.toFixed(digits)) : null;
const median = (values) => {
  const xs = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!xs.length) return null;
  const middle = Math.floor(xs.length / 2);
  return xs.length % 2 ? xs[middle] : (xs[middle - 1] + xs[middle]) / 2;
};
const max = (values) => {
  const xs = values.filter(Number.isFinite);
  return xs.length ? Math.max(...xs) : null;
};
const mean = (values) => {
  const xs = values.filter(Number.isFinite);
  return xs.length ? xs.reduce((total, value) => total + value, 0) / xs.length : null;
};
const valueText = (value, digits = 2) =>
  Number.isFinite(value) ? String(round(value, digits)) : "n/a";
const passText = (run) => {
  if (!run) return "missing";
  if (run.boundedStop) return "bounded service stop (partial)";
  if (!run.complete) return "incomplete measurement";
  return run.pass ? "pass" : "completed threshold failure";
};
const reportOf = (run) => run?.report || run?.assessment?.report || null;

async function readJson(name) {
  return JSON.parse(await readFile(path.join(artifactDir, name), "utf8"));
}

function csvCell(value) {
  if (value === null || value === undefined) return "";
  const string = String(value);
  return /[",\n]/.test(string) ? `"${string.replaceAll('"', '""')}"` : string;
}

function parseBytes(value) {
  if (Number.isFinite(value)) return value;
  if (typeof value === "string" && /^\s*\d+(?:\.\d+)?\s*$/.test(value)) return Number(value);
  const match = String(value || "").match(/^\s*([0-9.]+)\s*(B|KiB|MiB|GiB|KB|MB|GB)\b/i);
  if (!match) return null;
  const factors = { b: 1, kib: 1024, mib: 1024 ** 2, gib: 1024 ** 3, kb: 1000, mb: 1000 ** 2, gb: 1000 ** 3 };
  return Number(match[1]) * factors[match[2].toLowerCase()];
}

function parseCpu(value) {
  const match = String(value || "").match(/([0-9.]+)\s*%/);
  return match ? Number(match[1]) : null;
}

function serviceForContainer(container) {
  if (container?.service) return container.service;
  const name = container?.Name || container?.name || "";
  return coreServices.find((service) => name.includes(`-${service}-`)) || null;
}

function summarizeResources(samples, serviceLimits, expectedTutorReplicas) {
  const observations = [];
  const capChecks = [];
  for (const sample of samples) {
    const containers = sample.containers || [];
    const core = containers.filter((container) => coreServices.includes(serviceForContainer(container)));
    const counts = Object.fromEntries(coreServices.map((service) => [service, core.filter((item) => serviceForContainer(item) === service).length]));
    const countValid = Object.entries(expectedServiceCounts).every(([service, count]) => counts[service] === count)
      && counts["tutor-service"] === expectedTutorReplicas;
    const capValid = core.every((container) => {
      const service = serviceForContainer(container);
      const configured = serviceLimits?.[service];
      const configuredBytes = Number(configured?.memoryBytes);
      return configured && Number.isFinite(container.nanoCpus) && Number.isFinite(configured.cpus)
        && Math.abs(container.nanoCpus / 1e9 - configured.cpus) < 0.001
        && Number.isFinite(container.memoryBytes) && container.memoryBytes === configuredBytes;
    });
    capChecks.push(countValid && capValid);

    const byId = new Map(core.map((container) => [String(container.id || "").slice(0, 12), container]));
    const stats = sample.stats || [];
    const sampleCpu = [];
    const sampleMemory = [];
    const sampleCpuOfLimit = [];
    for (const stat of stats) {
      const container = byId.get(String(stat.ID || "").slice(0, 12))
        || core.find((item) => item.name && String(stat.Name || "").includes(item.name));
      if (!container) continue;
      const service = serviceForContainer(container);
      const cpu = parseCpu(stat.CPUPerc);
      const usedBytes = parseBytes(String(stat.MemUsage || "").split("/")[0]);
      const cpuLimit = Number(container.nanoCpus) / 1e9;
      if (Number.isFinite(cpu)) {
        sampleCpu.push(cpu);
        if (cpuLimit > 0) sampleCpuOfLimit.push((cpu / cpuLimit));
      }
      if (Number.isFinite(usedBytes)) sampleMemory.push(usedBytes);
      observations.push({ service, cpuPercent: cpu, cpuOfLimitPercent: cpuLimit > 0 && Number.isFinite(cpu) ? cpu / cpuLimit : null, memoryBytes: usedBytes });
    }
    if (sampleCpu.length || sampleMemory.length) {
      observations.push({
        aggregate: true,
        cpuHostPercent: sampleCpu.length ? sampleCpu.reduce((a, b) => a + b, 0) / sampleCpu.length : null,
        cpuOfLimitPercent: sampleCpuOfLimit.length ? sampleCpuOfLimit.reduce((a, b) => a + b, 0) / sampleCpuOfLimit.length : null,
        memoryMeanBytes: sampleMemory.length ? sampleMemory.reduce((a, b) => a + b, 0) / sampleMemory.length : null,
        memoryPeakBytes: max(sampleMemory),
      });
    }
  }
  const aggregates = observations.filter((observation) => observation.aggregate);
  return {
    snapshots: samples.length,
    capsAndReplicaCountsValid: samples.length > 0 && capChecks.every(Boolean),
    meanCpuHostPercent: mean(aggregates.map((row) => row.cpuHostPercent)),
    meanCpuOfLimitPercent: mean(aggregates.map((row) => row.cpuOfLimitPercent)),
    meanMemoryMiB: mean(aggregates.map((row) => row.memoryMeanBytes)) / (1024 ** 2) || null,
    peakMemoryMiB: max(aggregates.map((row) => row.memoryPeakBytes)) / (1024 ** 2) || null,
    services: Object.fromEntries(coreServices.map((service) => {
      const rows = observations.filter((row) => row.service === service);
      return [service, {
        meanCpuOfLimitPercent: mean(rows.map((row) => row.cpuOfLimitPercent)),
        peakMemoryMiB: max(rows.map((row) => row.memoryBytes)) / (1024 ** 2) || null,
      }];
    })),
  };
}

function metricRow({ name, phase, replicas, mode, rate, durationSeconds, run, resources }) {
  const report = reportOf(run);
  const overall = report?.overall || {};
  const row = {
    name,
    phase,
    replicas,
    mode,
    offered_rate_rps: mode === "arrival" ? rate : null,
    vus: mode === "concurrency" ? (run?.vus ?? report?.config?.vus) : null,
    requested_duration_s: durationSeconds,
    observed_duration_s: report?.observedDurationMs == null ? null : report.observedDurationMs / 1000,
    schedule_complete: report?.scheduleComplete ?? run?.scheduleComplete ?? false,
    measurement_complete: run?.complete ?? run?.assessment?.complete ?? false,
    bounded_stop: run?.boundedStop ?? run?.assessment?.boundedStop ?? false,
    outcome: passText(run),
    overall_p95_ms: overall.latency?.p95,
    broad_p95_ms: report?.categories?.broad?.latency?.p95,
    selective_p95_ms: report?.categories?.selective?.latency?.p95,
    availability_p95_ms: report?.categories?.availability?.latency?.p95,
    successful_rps: overall.successfulRequestsPerSecond,
    overall_error_rate: overall.combinedFailureRate,
    broad_error_rate: report?.categories?.broad?.combinedFailureRate,
    selective_error_rate: report?.categories?.selective?.combinedFailureRate,
    availability_error_rate: report?.categories?.availability?.combinedFailureRate,
    dropped_fraction: overall.droppedFraction,
    dropped_iterations: overall.droppedIterations,
    cpu_mean_of_limit_pct: resources?.meanCpuOfLimitPercent,
    cpu_mean_host_pct: resources?.meanCpuHostPercent,
    core_memory_mean_mib: resources?.meanMemoryMiB,
    core_memory_peak_mib: resources?.peakMemoryMiB,
    core_caps_and_replica_counts_valid: resources?.capsAndReplicaCountsValid,
  };
  return row;
}

function medianAndWorst(runs, pick) {
  const values = runs.map(pick).filter(Number.isFinite);
  return { median: median(values), worst: max(values) };
}

async function main() {
  const ledger = await readJson("ledger.json");
  const metadata = ledger.metadata || {};
  const fixture = metadata.fixture || {};
  const environment = await readJson("environment.json").catch(() => ({}));
  const fixtureFile = await readJson("fixture.json").catch(() => ({}));
  const supplement = await readJson("gateway-q03-status-samples.json").catch(() => null);
  const resourceLines = await readFile(path.join(artifactDir, "resources.jsonl"), "utf8").catch(() => "");
  const resourceSamples = resourceLines.split(/\r?\n/).filter(Boolean).map((line) => {
    try { return JSON.parse(line); } catch { return null; }
  }).filter(Boolean);
  const runSamples = new Map();
  for (const sample of resourceSamples) {
    if (!sample.label) continue;
    const list = runSamples.get(sample.label) || [];
    list.push(sample);
    runSamples.set(sample.label, list);
  }

  const measurementRuns = (ledger.runs || []).filter((run) => run.phase === "measurement");
  const metrics = [];
  for (const run of measurementRuns) {
    const replicas = run.result?.hostValidity?.replicas || run.assessment?.report?.config?.tutorReplicas || null;
    const resource = summarizeResources(runSamples.get(run.name) || [], metadata.resourceLimits, replicas);
    metrics.push(metricRow({
      name: run.name,
      phase: run.name?.startsWith("baseline-") ? "baseline" : run.name?.startsWith("q03-") ? "q03" : run.name?.startsWith("recovery-") ? "recovery" : "comparison",
      replicas,
      mode: run.mode,
      rate: run.ratePerSecond,
      durationSeconds: run.durationSeconds,
      run: run.assessment,
      resources: resource,
    }));
  }

  const comparisons = (ledger.comparisons || []).filter((entry) => Array.isArray(entry.outcomes));
  const baselineRate = ledger.baseline?.ratePerSecond ?? 80;
  const expectedRates = [0.8, 1, 1.5].map((multiplier) => Math.round(baselineRate * multiplier * 10) / 10);
  const receipts = [];
  for (const rate of expectedRates) for (const replicas of [1, 3]) for (let repeat = 1; repeat <= 3; repeat += 1) {
    const pair = comparisons.find((entry) => Math.abs(entry.ratePerSecond - rate) < 0.001 && entry.repeat === repeat);
    const outcome = pair?.outcomes?.find((item) => item.replicas === replicas);
    receipts.push({ rate, replicas, repeat, outcome, pair });
  }

  const resourceByRunName = new Map(metrics.map((row) => [row.name, row]));
  const completeLedger = Boolean(ledger.completedAt);
  const expectedComparisonCount = receipts.filter((receipt) => receipt.outcome).length;
  const fullScheduleCount = receipts.filter((receipt) => receipt.outcome?.complete).length;
  const guardedCount = receipts.filter((receipt) => receipt.outcome?.boundedStop).length;
  const missingCount = receipts.length - expectedComparisonCount;
  const resourceCaps = metadata.resourceLimits || {};
  const actualCoreCaps = environment.resourceLimits || resourceCaps;
  const metadataCapsValid = coreServices.every((service) => {
    const expected = resourceCaps[service];
    const actual = actualCoreCaps[service];
    return expected && actual && Number(expected.cpus) === Number(actual.cpus)
      && Number(expected.memoryBytes) === Number(actual.memoryBytes);
  });

  const baselineConfirmation = ledger.baseline?.confirmation || [];
  const baselineSummary = baselineConfirmation.map((run) => ({
    rate: run.ratePerSecond,
    repeat: run.repeat,
    report: run.report,
    complete: run.complete,
    pass: run.pass,
  }));
  const probeRuns = measurementRuns.filter((run) => run.name?.startsWith("baseline-probe-"));
  const q03 = ledger.q03 || [];
  const q03Pairs = [1, 2, 3].map((repeat) => {
    const one = q03.find((run) => run.replicas === 1 && run.repeat === repeat);
    const three = q03.find((run) => run.replicas === 3 && run.repeat === repeat);
    const oneRps = reportOf(one)?.overall?.successfulRequestsPerSecond;
    const threeRps = reportOf(three)?.overall?.successfulRequestsPerSecond;
    return { repeat, one, three, gain: Number.isFinite(oneRps) && oneRps > 0 && Number.isFinite(threeRps) ? threeRps / oneRps : null };
  });
  const q03Gains = q03Pairs.map((pair) => pair.gain).filter(Number.isFinite);
  const q03Stats = (replicas) => {
    const rows = q03.filter((run) => run.replicas === replicas);
    return {
      p95: medianAndWorst(rows, (run) => reportOf(run)?.overall?.latency?.p95),
      successRps: medianAndWorst(rows, (run) => reportOf(run)?.overall?.successfulRequestsPerSecond),
      successRpsPerConfiguredTutorCpu: median(rows.map((run) => reportOf(run)?.overall?.successfulRequestsPerSecond).map((value) => Number.isFinite(value) ? value / (Number(resourceCaps["tutor-service"]?.cpus) * replicas) : null)),
      errorRate: medianAndWorst(rows, (run) => reportOf(run)?.overall?.combinedFailureRate),
      categoryWorstP95: Object.fromEntries(categories.map((category) => [category, max(rows.map((run) => reportOf(run)?.categories?.[category]?.latency?.p95))])),
      thresholdPasses: rows.filter((run) => run.pass).length,
      runs: rows.length,
    };
  };

  const groupSummaries = [];
  for (const rate of expectedRates) for (const replicas of [1, 3]) {
    const rows = receipts.filter((receipt) => receipt.rate === rate && receipt.replicas === replicas);
    const runs = rows.map((row) => row.outcome).filter(Boolean);
    const reports = runs.map(reportOf);
    const metricsAtRate = rows.map((row) => {
      const multiplier = baselineRate > 0 ? rate / baselineRate : 1;
      const name = `compare-${replicas}-replica-${Math.round(multiplier * 100)}pct-repeat-${row.repeat}`;
      return resourceByRunName.get(name);
    }).filter(Boolean);
    groupSummaries.push({ rate, replicas, runs, reports, metricsAtRate });
  }

  const lines = [
    "# Discovery capacity experiment analysis",
    "",
    `Receipt: ${completeLedger ? "main ledger completed" : "MISSING: ledger.completedAt is absent; this is an interim artifact review"}.`,
    `Experiment started: ${ledger.startedAt || "unknown"}; completed: ${ledger.completedAt || "pending"}.`,
    `Measured revision: ${metadata.baseRevision || "unknown"}.`,
    `Baseline: ${ledger.baseline?.ratePerSecond ?? "not confirmed"} RPS; ${baselineSummary.filter((run) => run.complete && run.pass).length}/${baselineSummary.length} confirmation runs passed their recorded assessments.`,
    `Comparison receipt: ${expectedComparisonCount}/18 expected rate × replica × repeat cases found; ${fullScheduleCount} full scheduled, ${guardedCount} bounded-stop partial, ${missingCount} missing. Threshold failures with complete measurement data are recorded observations, not missing cases.`,
    "",
    "## Scope and fixture",
    "",
    `The planned comparison covers 18 arrival-rate measurements: ${expectedRates.join(", ")} offered RPS × 1 or 3 Tutor replicas × three repeats, with a 300-second target per repeat. It also includes six Q-03 measurements at a fixed 50 virtual users (VUs) × 30 seconds and six 80% recovery measurements after the 150% overload points. Q-03 uses a concurrency executor and has no offered-RPS target; the arrival tests' preallocated VUs are capacity for the generator, not 50 simultaneous users.`,
    `Fixture: ${fixture.tutorCount ?? fixtureFile.fixture?.tutorCount ?? "?"} tutors, ${fixture.subjectCount ?? fixtureFile.fixture?.subjectCount ?? "?"} subjects, ${fixture.reviewCount ?? fixtureFile.fixture?.reviewCount ?? "?"} Review record(s); 12 available and 12 unavailable tutors when fixture counts are present. One real eligible Review is combined with Booking-owned historical availability. Real unrated, rated, and availability query categories are represented.`,
    `Dataset sweep: ${metadata.datasetSweep === false ? "not run; one fixed 24-tutor/48-subject dataset" : "see ledger metadata"}.`,
    "",
    "## Receipt by offered rate and replica count",
    "",
    "| Offered RPS | Tutor replicas | Repeat 1 | Repeat 2 | Repeat 3 | 300s complete | Guarded partial | Completed threshold failures |",
    "|---:|---:|---|---|---|---:|---:|---:|",
  ];
  for (const group of groupSummaries) {
    const statuses = [1, 2, 3].map((repeat) => {
      const item = receipts.find((receipt) => receipt.rate === group.rate && receipt.replicas === group.replicas && receipt.repeat === repeat);
      return passText(item?.outcome);
    });
    lines.push(`| ${group.rate} | ${group.replicas} | ${statuses[0]} | ${statuses[1]} | ${statuses[2]} | ${group.runs.filter((run) => run.complete).length} | ${group.runs.filter((run) => run.boundedStop).length} | ${group.runs.filter((run) => run.complete && !run.pass).length} |`);
  }
  lines.push("", "## Aggregate workload summaries", "", "Worst p95 means the maximum of per-run p95 values; percentiles are not pooled or averaged. These aggregate metrics include only full scheduled runs, including completed threshold failures. Guarded partial runs remain in the receipt and CSV with observed duration, but their p95/error percentages may include canceled in-flight requests and are excluded from full-duration steady-state aggregates.", "", "| Offered RPS | Replicas | Median successful RPS | Worst full-run overall p95 ms | Worst broad p95 | Worst selective p95 | Worst availability p95 | Max full-run error | Max full-run dropped fraction | 300s complete | Guarded partial | Completed threshold failures |", "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const group of groupSummaries) {
    const runs = group.runs.filter((run) => run.complete && !run.boundedStop);
    const reports = runs.map(reportOf);
    const worstCategory = Object.fromEntries(categories.map((category) => [category, max(reports.map((report) => report?.categories?.[category]?.latency?.p95))]));
    const allRuns = group.runs;
    lines.push(`| ${group.rate} | ${group.replicas} | ${valueText(median(reports.map((report) => report?.overall?.successfulRequestsPerSecond)))} | ${valueText(max(reports.map((report) => report?.overall?.latency?.p95)))} | ${valueText(worstCategory.broad)} | ${valueText(worstCategory.selective)} | ${valueText(worstCategory.availability)} | ${valueText(max(reports.map((report) => report?.overall?.combinedFailureRate)), 4)} | ${valueText(max(reports.map((report) => report?.overall?.droppedFraction)), 4)} | ${allRuns.filter((run) => run.complete).length}/3 | ${allRuns.filter((run) => run.boundedStop).length}/3 | ${allRuns.filter((run) => run.complete && !run.pass).length}/3 |`);
  }
  const oneReplicaAt120 = receipts.filter((receipt) => receipt.rate === 120 && receipt.replicas === 1).map((receipt) => receipt.outcome).filter(Boolean);
  if (oneReplicaAt120.length) {
    const bounded = oneReplicaAt120.filter((run) => run.boundedStop).length;
    const full = oneReplicaAt120.filter((run) => run.complete && !run.boundedStop).length;
    lines.push("", `At 120 RPS with one Tutor replica, ${full}/3 runs completed the full scheduled measurement and ${bounded}/3 ended at the configured service guard. Guard-stopped samples are partial; their latency/error metrics are not treated as five-minute measurements.`);
  }

  const recoveries = (ledger.comparisons || []).filter((entry) => entry.recovery);
  lines.push("", "## Recovery after each 150% overload run", "", "| Replicas | Repeat | Recovery rate | Status | Overall p95 | Broad p95 | Selective p95 | Availability p95 | Error rate | Dropped fraction |", "|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|");
  for (const entry of recoveries) {
    const report = reportOf(entry.recovery);
    lines.push(`| ${entry.replicas} | ${entry.repeat} | ${Math.round(baselineRate * 0.8 * 10) / 10} RPS | ${passText(entry.recovery)} | ${valueText(report?.overall?.latency?.p95)} | ${valueText(report?.categories?.broad?.latency?.p95)} | ${valueText(report?.categories?.selective?.latency?.p95)} | ${valueText(report?.categories?.availability?.latency?.p95)} | ${valueText(report?.overall?.combinedFailureRate, 4)} | ${valueText(report?.overall?.droppedFraction, 4)} |`);
  }

  const stats1 = q03Stats(1);
  const stats3 = q03Stats(3);
  lines.push("", "## Q-03 concurrency: 50 VUs for 30 seconds", "", "This workload holds 50 concurrent virtual users. It is separate from the 64/80/120 offered-RPS arrival workloads; its `ratePerSecond` metadata field is not an offered request rate.", "", "| Tutor replicas | Runs | Median successful RPS | Median overall p95 ms | Worst overall p95 ms | Worst broad p95 | Worst selective p95 | Worst availability p95 | Worst error rate | Acceptance passes |", "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const [replicas, stats] of [[1, stats1], [3, stats3]]) lines.push(`| ${replicas} | ${stats.runs} | ${valueText(stats.successRps.median)} | ${valueText(stats.p95.median)} | ${valueText(stats.p95.worst)} | ${valueText(stats.categoryWorstP95.broad)} | ${valueText(stats.categoryWorstP95.selective)} | ${valueText(stats.categoryWorstP95.availability)} | ${valueText(stats.errorRate.worst, 4)} | ${stats.thresholdPasses}/${stats.runs} |`);
  const arrival120Three = groupSummaries.find((group) => group.rate === 120 && group.replicas === 3);
  const arrival120Full = arrival120Three?.runs.filter((run) => run.complete && !run.boundedStop) || [];
  lines.push("", `For mode-aware context, Q-03 50-VU concurrency has median overall p95 ${valueText(stats1.p95.median)} ms (1 replica) and ${valueText(stats3.p95.median)} ms (3 replicas); the separate 120 offered-RPS/3-replica arrival workload has worst full-run overall p95 ${valueText(max(arrival120Full.map((run) => reportOf(run)?.overall?.latency?.p95)))} ms. These are different executors and populations, not equivalent request rates.`);
  const q03CpuLimitRatio = q03Pairs.map((pair) => pair.gain / 3).filter(Number.isFinite);
  lines.push("", `Paired three-replica / one-replica successful-throughput ratios: ${q03Pairs.map((pair) => `repeat ${pair.repeat} ${valueText(pair.gain, 3)}×`).join("; ") || "unavailable"}. Median gain is ${valueText(median(q03Gains), 3)}× (range ${valueText(Math.min(...q03Gains), 3)}–${valueText(Math.max(...q03Gains), 3)}×) from ${q03Gains.length}/3 paired repeats.`, `The configured Tutor CPU limit is ${valueText(Number(resourceCaps["tutor-service"]?.cpus) || 0.5, 2)} CPU per replica: 0.5 CPU at one replica and 1.5 CPU at three. Paired throughput-per-configured-Tutor-CPU ratio (throughput gain divided by three) has median ${valueText(median(q03CpuLimitRatio), 3)}× and range ${valueText(Math.min(...q03CpuLimitRatio), 3)}–${valueText(Math.max(...q03CpuLimitRatio), 3)}×. These are CPU limits/ceilings, not reservations or dedicated cores; this Tutor-only comparison is not whole-deployment efficiency. Fixed other service limits make the whole-app configured CPU ceiling 5.6→6.6 CPU (+18%) excluding the load generator, or 6.6→7.6 CPU including it; recorded peak budget is 7.6 CPU.`, "The Q-03 p95 target is 500 ms and error target is below 1%. Results above those thresholds remain measured outcomes; replica throughput gains do not imply latency acceptance.");

  lines.push("", "## Baseline discovery and confirmation", "", `Short probes passed at: ${(ledger.baseline?.passingRates || []).join(", ") || "none"} RPS. Failed or bounded probes: ${(ledger.baseline?.failedRates || []).join(", ") || "none"} RPS.`, `Confirmed sustained baseline: ${ledger.baseline?.ratePerSecond ?? "unavailable"} RPS; failed upper bound: ${ledger.baseline?.failedUpperBound ?? "not established"} RPS. This is an observed sustainable rate/bracket, not a proven theoretical maximum.`, "", "| Repeat | Rate | Complete | Pass | Overall p95 | Broad p95 | Selective p95 | Availability p95 | Error rate | Dropped fraction |", "|---:|---:|:---:|:---:|---:|---:|---:|---:|---:|---:|");
  for (const run of baselineSummary) {
    const report = run.report;
    lines.push(`| ${run.repeat} | ${run.rate} | ${run.complete ? "yes" : "no"} | ${run.pass ? "yes" : "no"} | ${valueText(report?.overall?.latency?.p95)} | ${valueText(report?.categories?.broad?.latency?.p95)} | ${valueText(report?.categories?.selective?.latency?.p95)} | ${valueText(report?.categories?.availability?.latency?.p95)} | ${valueText(report?.overall?.combinedFailureRate, 4)} | ${valueText(report?.overall?.droppedFraction, 4)} |`);
  }
  lines.push("", "Short-probe boundary observations:", "", "| Rate | Status | Overall p95 | Broad p95 | Selective p95 | Availability p95 | Error rate | Dropped fraction |", "|---:|---|---:|---:|---:|---:|---:|---:|");
  for (const run of probeRuns) {
    const report = run.assessment?.report;
    const status = run.assessment?.boundedStop ? "bounded stop" : run.assessment?.complete ? run.assessment?.pass ? "pass" : "threshold failure" : "invalid/incomplete";
    lines.push(`| ${run.ratePerSecond} | ${status} | ${valueText(report?.overall?.latency?.p95)} | ${valueText(report?.categories?.broad?.latency?.p95)} | ${valueText(report?.categories?.selective?.latency?.p95)} | ${valueText(report?.categories?.availability?.latency?.p95)} | ${valueText(report?.overall?.combinedFailureRate, 4)} | ${valueText(report?.overall?.droppedFraction, 4)} |`);
  }

  lines.push("", "## API service resource use and cap checks", "", `Ledger resource limits match the resource values recorded in environment metadata: ${metadataCapsValid ? "yes" : "no or missing evidence"}. Snapshots confirm expected replica counts and limits for the five measured API services (Auth, Gateway, Tutor, Booking, Review) across sampled workload windows: ${metrics.length && metrics.every((row) => row.core_caps_and_replica_counts_valid) ? "yes" : "no or missing evidence"}. MongoDB, RabbitMQ, Traefik, and other host processes are not included in the API-service CPU/memory aggregate.`, "CPU mean-of-limit is summarized from sampled Docker `CPUPerc` divided by each container's declared CPU limit; memory is Docker stats working-set usage. Resource sampling includes startup/drain where labels overlap the measurement; it is observational, not a precise per-request attribution.", "", "| Offered RPS | Replicas | Repeat | Mean API-service CPU of limit | Mean API-service memory MiB | Peak API-service memory MiB | Cap/snapshot valid |", "|---:|---:|---:|---:|---:|---:|:---:|");
  for (const receipt of receipts) {
    const multiplier = baselineRate > 0 ? receipt.rate / baselineRate : 1;
    const name = `compare-${receipt.replicas}-replica-${Math.round(multiplier * 100)}pct-repeat-${receipt.repeat}`;
    const row = receipt.outcome && resourceByRunName.get(name);
    lines.push(`| ${receipt.rate} | ${receipt.replicas} | ${receipt.repeat} | ${valueText(row?.cpu_mean_of_limit_pct)}% | ${valueText(row?.core_memory_mean_mib)} | ${valueText(row?.core_memory_peak_mib)} | ${row?.core_caps_and_replica_counts_valid ? "yes" : "no/missing"} |`);
  }
  lines.push("", `Tutor replicas observed per resource sample are checked against the requested topology; Auth, Gateway, Booking, and Review are each expected at one replica. Declared core limits: ${coreServices.map((service) => `${service} ${resourceCaps[service]?.cpus ?? "?"} CPU / ${valueText(parseBytes(resourceCaps[service]?.memoryBytes) / (1024 ** 2))} MiB`).join("; ")}.`);

  if (supplement) {
    const windows = supplement.windows || {};
    lines.push("", "## Supplemental gateway status evidence", "", supplement.note || "Supplemental samples include warm-up/startup/drain and are not exact k6 totals.", "");
    for (const [name, window] of Object.entries(windows)) {
      lines.push(`- ${name}: statuses ${JSON.stringify(window.statuses || {})}; origins ${JSON.stringify(window.origins || {})}; retry attempts ${JSON.stringify(window.retryAttempts || {})}.`);
    }
    lines.push("The supplemental gateway log review found the 503 responses had origin status 0, no `ServiceAddr`, and retry count 0; the exact ingress cause remains unproven because Traefik active-health state was not sampled. This supplemental window includes warm-up, process startup, and drain; it is not an exact k6 request total.");
  } else lines.push("", "Supplemental gateway Q-03 status sample file is missing.");

  lines.push("", "## Provenance, limitations, and scope", "", `- Tested source revision: ${metadata.baseRevision || "missing"}.`, `- Fixture: ${fixture.tutorCount ?? "?"} tutors / ${fixture.subjectCount ?? "?"} subjects; ${fixture.reviewCount ?? "?"} real Review row(s), plus Booking-owned historical availability seed.`, `- Prior interrupted sibling retained: ${path.basename(artifactDir)}-interrupted. Earlier gateway budget was 256 MiB; canonical run budget is ${valueText(parseBytes(resourceCaps["api-gateway"]?.memoryBytes) / (1024 ** 2))} MiB.`, "- The fixed dataset does not establish a capacity curve across larger catalogue sizes.", "- Per-run p95 values are summarized as worst-run p95; they are not pooled across runs.", "- This analysis is a measurement report only. It proposes no application changes.", "");

  const headers = Object.keys(metrics[0] || {
    name: "", phase: "", replicas: "", mode: "", offered_rate_rps: "", vus: "", requested_duration_s: "", observed_duration_s: "", schedule_complete: "", measurement_complete: "", bounded_stop: "", outcome: "", overall_p95_ms: "", broad_p95_ms: "", selective_p95_ms: "", availability_p95_ms: "", successful_rps: "", overall_error_rate: "", broad_error_rate: "", selective_error_rate: "", availability_error_rate: "", dropped_fraction: "", dropped_iterations: "", cpu_mean_of_limit_pct: "", cpu_mean_host_pct: "", core_memory_mean_mib: "", core_memory_peak_mib: "", core_caps_and_replica_counts_valid: "",
  });
  const csv = [headers.join(","), ...metrics.map((row) => headers.map((key) => csvCell(row[key])).join(","))].join("\n") + "\n";
  await writeFile(path.join(artifactDir, "analysis.md"), lines.join("\n"));
  await writeFile(path.join(artifactDir, "measurements.csv"), csv);
  process.stdout.write(`Wrote analysis.md and measurements.csv under ${artifactDir}. Receipt: ${completeLedger ? "complete" : "incomplete"}; ${expectedComparisonCount}/18 comparison cases present.\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error}\n`);
  process.exitCode = 1;
});
